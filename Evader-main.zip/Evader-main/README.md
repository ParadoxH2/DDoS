# Evader     
 Undetectable Reverse shell with Xor encrypting with custom KEY(FUD Metasploit Rat) bypass Top Antivirus like   BitDefender,Malwarebytes,Avast,ESET-NOD32,AVG etc..

<img src="https://i.ibb.co/4f9tWg4/EVADER.png"/> 
 
[![Version](https://img.shields.io/badge/Evader-1.0.1-brightgreen.svg?maxAge=259200)]()
[![Version](https://img.shields.io/badge/Codename-BlackHat-red.svg?maxAge=259200)]()
[![Stage](https://img.shields.io/badge/Release-Stable-brightgreen.svg)]()
[![Build](https://img.shields.io/badge/Supported_OS-Linux-orange.svg)]()
[![Available](https://img.shields.io/badge/Available-KaliLinux-orange.svg?maxAge=259200)]()
[![Documentation](https://img.shields.io/badge/Dev_Mukherjee-Hacktidu-red.svg?maxAge=259200)]()
[![Contributions Welcome](https://img.shields.io/badge/Type-FUD-blue.svg?style=flat)]()

###  Undetectable Reverse shell (Metasploit Rat) 

**Evader** is an payload maker tool which can make payloads in raw format with icon and then encrypts with xor encryption with custom key.There is a manifest which can be injected into it to make the pay payload - 
🔴 **BitDefender**
🔴 **NOD32**
🔴 **Malwarebytes**
🔴 **AVG**
🔴 **Avast**

 ## Features !
- python3 and Ngrok support.
- Automatically Xor encrypting with custum KEY that you can use for increasing bypass Av.
- Automatically Add Icon to executable.
- Automatically Add Manifest to executable.
- Bypass anti-virus backdoors with pure raw and xor.
- Support os windows 7 to windows 10.
- Fully Automating MSFvenom & Metasploit.
- custum icon (copy your icon to icon folder and rename it to icon.ico)
- add PowerShell to silent executable.
- bypass Top Antivirus like BitDefender,Malwarebytes,Avast,ESET-NOD32,AVG,...

## Installation & How To Use
```
git clone https://github.com/dev-mukherjee/Evader.git
cd Evader
chmod +x install.sh
./install.sh
./evader.py or python3 evader.py
```
# Requirements
🔴 Kali Linux <br/>
🔴 Python3 <br/>
🔴 Metasploit Framework <br/>
🔴 Wine <br/>
🔴 Mingw-w64 Compiler <br/>

## Contact me
🔴 admin@hacktidu.in - **Email**<br/>
🔴 https://hacktidu.in - **WEBSITE**<br/>
🔴 https://bit.ly/3zkm3HA - **Youtube**<br/>
🔴 https://bit.ly/2TToalk - **Instgram**<br/>
🔴 https://bit.ly/2U2v485 - **Whatsapp Group**<br/>
🔴 https://bit.ly/3xjEQkm - **Facebook Group**<br/>

## Information

 This tool is for educational purpose only, usage of Evader for attacking targets without prior mutual consent is illegal.
 Developers assume no liability and are not responsible for any misuse or damage cause by this program.
